import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.sql.* ;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.PrintWriter;
/**
 * Servlet implementation class UserRegistrationServlet
 */
@WebServlet("/register")
@MultipartConfig
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		    response.setContentType("text/html; charset=utf-8");
		    PrintWriter out = response.getWriter();
	        //connect mysql user -u zsui1 -p 1
		    String docType = "<!doctype html>\n";
//		     String studentname = request.getParameter("studentName");
         
	        String name = request.getParameter("username");
	        String email = request.getParameter("email");
	        String password1 = request.getParameter("password1");
	        String password2 = request.getParameter("password2");
           

			
	        
		    if(name.isEmpty()|| email.isEmpty()|| password1.isEmpty()|| password2.isEmpty()||! password1.equals(password2)) {
		    	
		    	out.println(docType +
		    			"<html>\n"+
		    			"<body>\n"+
		    			"<p>"+"Your input: information is not complete,try again"+"</p>"+"<a href="+"MainPage1.html"+">"+"go back"+"<a>"+"\n"+
		    			"</body></html>");
		    }else{
		    	
		    	  out.println(docType +
			    			"<html>\n"+
			    			"<body>\n"+
			    			"<p>"+"success registration, welcome"+name+"</p>"+"<a href="+"MainPage1.html"+"?"+"name"+name+">"+"go back"+"<a>"+"\n"+
			    			"</body></html>");
				   // JDBC driver name and database URLString JDBC_DRIVER = "com.mysql.jdbc.Driver";
			      //String DB_URL = "jdbc:mysql://52.26.86.130:3306/student";
			      String DB_URL = "jdbc:mysql://3.143.220.151:3306/testDB";
			      // Database credentials
			      String USER = "zsui1";
			      String PASS = "1";
			      Connection conn = null;
			      Statement stmt = null;
			    try { 
				      Class.forName("com.mysql.jdbc.Driver");
				      //STEP 3: Open a connection
				      System.out.println("Connecting to database...");
				      conn = (Connection) DriverManager.getConnection(DB_URL,USER,PASS);
				      //STEP 4: Execute a query
				      System.out.println("Creating statement...");
				      PreparedStatement st = conn.prepareStatement("insert into user values(?,?,?)");
				      st.setString(1,name);
				      st.setString(2, email);
				      st.setString(3, password1);
				      st.executeUpdate();
					     
					      st.close();
					      conn.close();
					      } catch (ClassNotFoundException | SQLException e) {
					      // TODO Auto-generated catch block
					      e.printStackTrace();
					      }
		    }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
